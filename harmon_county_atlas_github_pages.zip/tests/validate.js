/* Optional local checks. Run: node tests/validate.js */
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const paths = ['styles.css', 'app.js', 'data/places.js'];
for (const p of paths) {
  if (!fs.existsSync(path.join(root, p))) throw new Error(`Missing local asset: ${p}`);
  if (!html.includes(`"${p}"`)) throw new Error(`index.html does not reference: ${p}`);
}
const context = { window: {} };
vm.runInNewContext(fs.readFileSync(path.join(root, 'data/places.js'), 'utf8'), context);
const places = context.window.ATLAS_PLACES;
if (!Array.isArray(places)) throw new Error('window.ATLAS_PLACES is not an array');
const ids = new Set();
for (const p of places) {
  if (!p.id || typeof p.id !== 'string') throw new Error('Record missing string id');
  if (ids.has(p.id)) throw new Error(`Duplicate record ID: ${p.id}`);
  ids.add(p.id);
  if (!p.name || typeof p.name !== 'string') throw new Error(`${p.id}: missing name`);
  if (!Number.isFinite(p.lat) || !Number.isFinite(p.lng) || Math.abs(p.lat) > 90 || Math.abs(p.lng) > 180) throw new Error(`${p.id}: invalid coordinates`);
  if (!['exact','approximate','unknown'].includes(p.locationAccuracy)) throw new Error(`${p.id}: invalid locationAccuracy`);
  if (!['verified','draft'].includes(p.status)) throw new Error(`${p.id}: invalid status`);
  if (p.status === 'verified' && (!Array.isArray(p.sources) || !p.sources.length)) throw new Error(`${p.id}: verified record has no sources`);
}
console.log(`PASS: all required local files exist; ${places.length} records validated.`);
